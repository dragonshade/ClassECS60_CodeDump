#include <iostream>
#include "BTree.h"
#include "BTreeNode.h"
#include "LeafNode.h"
#include "InternalNode.h"
using namespace std;

BTree::BTree(int ISize, int LSize):internalSize(ISize), leafSize(LSize)
{
  root = new LeafNode(LSize, NULL, NULL, NULL);
} // BTree::BTree()


void BTree::insert(const int value)
{
  // students must write this

  BTreeNode newNode= (BTreeNode *) root->insert(x)  //This invokes leaf insertion or internal node insertion
    if(newNode==NULL)  //nothing dramatic happens
   {                   //Adoption at best, no splitting
    }
   else{
        //Check if root is full
        if{root->count=} //If not full
         {
          
          //attach the newNode to root
          
         }
                
        //if full we need to split root
        root->insert(root,newNode);

    }
    
} // BTree::insert()


void BTree::print()
{
  BTreeNode *BTreeNodePtr;
  Queue<BTreeNode*> queue(1000);

  queue.enqueue(root);
  while(!queue.isEmpty())
  {
    BTreeNodePtr = queue.dequeue();
    BTreeNodePtr->print(queue);
  } // while
} // BTree::print()
